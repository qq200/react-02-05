import React from 'react';
import DayWeather from './weather/DayWeather'

function App() {
  return (
    <div >
      <DayWeather/>
    </div>
  );
}

export default App;

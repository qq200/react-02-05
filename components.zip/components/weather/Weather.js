//BUSINESS logic
//data structures/ exchenge
import axios from 'axios'

const KEY='39a176e8bc91f23f7ec20a1fa3159409';
const URL=`http://api.openweathermap.org/data/2.5/weather?q=London,uk&appid=${KEY}`;

class Day{
    constructor(date, icon, temp){
        this.date=date;
        this.icon=icon;
        this.temp=temp;
    }
}


class WeatherService{
        static getWeatherData(){    /////////////static metods-permite sa utilizezi o metoda direct din clasa fara sa creezi obiecte!!!!!
            axios.get(URL)
                    .then(response=>{
                        let d=new Day("","", response.data.main.temp);
                        console.log(d);
                    })
            return new Day("01-01-2019", "1.png", 22);

        }
}
export default WeatherService
//let d=new Day(01-01-20, "1.png", 25)
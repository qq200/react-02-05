import React, {Component} from 'react'
import './DayWeather.scss'
import WeatherService from './Weather'



//presentation logic
class DayWeather extends Component{
    constructor(){
        super();
        this.state={
            data:WeatherService.getWeatherData()
        }
    }

    


    render(){
        const {date,icon,temp}=this.state.data;
        return(
        <div className="day--weather">
            <img src={icon}/>
            <h3> Thu {date}</h3>
            <p>{temp}</p>


        </div>
        )
    }

}
export default DayWeather;